Hello <?php echo htmlspecialchars($_POST['name']); ?>.

<br>

<div>
<a class="btn btn-primary" role="button">
<button class="btn btn-primary" type="submit">Continue</button>
</div>