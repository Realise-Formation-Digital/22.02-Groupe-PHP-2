<?php

// Hero or Monster attacks first?

random 


// Hero attacks first

if Hero's power > Monster's stamina -> Hero strikes Monster
else Hero is hurt 


// Monster attacks

if Monster's power > Hero's stamina -> Monster strikes Hero
else Monster is hurt


// who is alive?

if Hero's life > 0 -> the fight continues 
else Hero is dead -> end of the game


// Hero's and Monster's stats 

?>