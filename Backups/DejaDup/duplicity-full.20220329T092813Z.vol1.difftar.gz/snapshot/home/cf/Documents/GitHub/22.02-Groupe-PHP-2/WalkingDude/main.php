<?php
    if(isset($_POST['submit'])){
        if(!empty($_POST['Hero'])) {
        $selected = $_POST['Hero'];
        } 
        else {
        }
    }

    if(isset($_POST['submit'])){
        if(!empty($_POST['Monster'])) {
            $selected = $_POST['Monster'];
        } 
        else {  
        }
    }

    if(isset($_POST['submit'])){
        if(!empty($_POST['Merchant'])) {
            $selected = $_POST['Merchant'];
        } 
        else {
        }
    }

    if(isset($_POST['submit'])){
        if(!empty($_POST['Arms'])) {
            $selected = $_POST['Arms'];                   
        } 
        else {
        }
    }
?>