<?php

class Humain{

    public $life;
    public $xp;
    public $strength;
    public $stamina;
    public $coins;

}