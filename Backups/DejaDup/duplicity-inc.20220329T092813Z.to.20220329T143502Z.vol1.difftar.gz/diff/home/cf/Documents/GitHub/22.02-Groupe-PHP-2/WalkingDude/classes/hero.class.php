rs6B�


<?php

include "human.class.php";


class Hero extends Human{

        public $name;
        
        public $bag = [];
        
        // public function __construct(){

        //         $this->name = $_POST['names'];
        //         $this->hero = $_POST['choix_hero'];
               
        //         if($this->hero == "TortueGeniale"){
        //             $heros = new TortueGeniale;
        //         }
        
        

        public function getNom(){
            return $this->name;
  J  B�new Armes()];
        }
    }

    
    


    



    ?>

<!-- object(TortueGenial)#1 (7) 
{ ["life"]=> int(10) 
    ["xp"]=> int(0) 
    ["strength"]=> int(3) 
    ["stamina"]=> int(1) 
    ["coins"]=> int(20) 
    ["name"]=> string(5) "elyes" 
    ["bag"]=> array(1) { [0]=> object(Armes)#3 (5) { ["life"]=> NULL ["xp"]=> NULL ["strength"]=> int(42) ["stamina"]=> int(43) ["coins"]=> int(32) } } } -->
 