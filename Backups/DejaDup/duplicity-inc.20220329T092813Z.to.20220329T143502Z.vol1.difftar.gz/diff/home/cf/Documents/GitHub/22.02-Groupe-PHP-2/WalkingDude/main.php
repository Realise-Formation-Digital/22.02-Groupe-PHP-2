rs6F  A�      if(!empty($_POST['Weapon'])) {
            $selected = $_POST['Weapon'];                   
        } 
        else {
        }
    }
?>
 