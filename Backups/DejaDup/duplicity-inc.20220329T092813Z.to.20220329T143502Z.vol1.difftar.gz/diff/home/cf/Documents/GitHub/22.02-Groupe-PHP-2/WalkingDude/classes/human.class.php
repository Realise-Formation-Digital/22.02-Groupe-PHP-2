rs6Ax<?php

class Human{

    public $life;
    public $xp;
    public $strength;
    public $stamina;
    public $coins;

}
 